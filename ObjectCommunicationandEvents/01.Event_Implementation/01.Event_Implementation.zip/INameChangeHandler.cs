﻿public interface INameChangeHandler
{
    void OnDispacherNameChange(object sender, NameChangeEventArgs args);
}